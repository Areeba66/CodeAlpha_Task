document.addEventListener("DOMContentLoaded", () => {
    const filterButtons = document.querySelectorAll(".filter-btn");
    const galleryItems = document.querySelectorAll(".gallery-item");

    // Filter functionality
    filterButtons.forEach(button => {
        button.addEventListener("click", () => {
            const category = button.getAttribute("data-category");
            filterButtons.forEach(btn => btn.classList.remove("active"));
            button.classList.add("active");

            galleryItems.forEach(item => {
                if (category === "all" || item.getAttribute("data-category") === category) {
                    item.style.display = "block";
                    setTimeout(() => item.classList.remove("hidden"), 10);
                } else {
                    item.classList.add("hidden");
                    setTimeout(() => (item.style.display = "none"), 400);
                }
            });
        });
    });
});
